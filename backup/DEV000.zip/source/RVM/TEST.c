#include<stdio.h>
#include<stdlib.h>

main()
{
	short a = 0x8001;
	printf("%d\n",(char)(a>>8));
	a = a>>8;
	a = a<<8;
	printf("%d\n",a);
	return 0;
}
