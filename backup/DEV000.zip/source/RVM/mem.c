/*
 * Write register and memory here
*/
#include"macro.c"
#include"custom.c"

typedef int 			RASM_DWORD;
typedef unsigned int	RASM_uDWORD; 
typedef short 			RASM_WORD;
typedef unsigned short 	RASM_uWORD;
typedef char 			RASM_BYTE;

enum RASM_REG_ENUM{
	RASM_AX=0,RASM_BX,RASM_CX,RASM_DX,
	RASM_EAX,RASM_EBX,RASM_ECX,RASM_EDX,
	RASM_PBP,RASM_PEP,RASM_RBP,RASM_REP,
	RASM_CF,RASM_AF,RASM_ZF,RASM_SF,
	RASM_INBP,RASM_INEP,RASM_OUBP,RASM_OUEP,RASM_APIB,RASM_APIE,
	RASM_ER,RASM_FR,RASM_GR,
	RASM_REG_SIZE
};

enum RASM_REG_LH_ID{
	RASM_AL=0,RASM_AH,
	RASM_BL,RASM_BH,
	RASM_CL,RASM_CH,
	RASM_DL,RASM_DH,
	RASM_REG_LH_SIZE
};

enum RASM_MOV_PACK_TYPE{
	RASM_MPT_USM = 0,
	RASM_MPT_REG,
	RASM_MPT_NUM
};

typedef struct{
	int type;
	void* val;
}RASM_MOV_PACK;

typedef struct{
	int topnl;
	RASM_WORD data[32767];
}RASM_STACK_TYPE;

RASM_WORD RASM_REG[RASM_REG_SIZE-1];								//register
RASM_BYTE RASM_MEM[RASM_USER_MEM_PARTITION][64*1024] = {0}; 		//memory
RASM_BYTE RASM_CODE[RASM_CODE_MEM_PARTITION]; 						//code memory
RASM_STACK_TYPE RASM_STACK;											//stack
unsigned int RASM_CS;												//running address
unsigned int RASM_LP;												//label point
unsigned int RASM_MEM_NP = 0;										//now partition

RASM_BOOL  RASM_MOV_PVAL_SET(void*,RASM_uWORD);
RASM_BOOL  RASM_MOV_PACK_SET(RASM_MOV_PACK,int,void*);
RASM_BOOL  RASM_MOV(RASM_MOV_PACK,RASM_MOV_PACK);
RASM_BOOL  RASM_MOVE(RASM_MOV_PACK,RASM_MOV_PACK);
RASM_BOOL  RASM_MOVL(RASM_MOV_PACK);
RASM_BOOL  RASM_MOVC(RASM_MOV_PACK,RASM_MOV_PACK);
RASM_BOOL  RASM_CALLL(void); 
RASM_BOOL  RASM_PUSH(RASM_MOV_PACK);
RASM_BOOL  RASM_POP(RASM_MOV_PACK);

RASM_BOOL RASM_MOV_PACK_SET(RASM_MOV_PACK* src,int type,void* val)
{
	if(src==NULL)	return RASM_FALSE;
	else{
		src->type = type;
		src->val  = val;
		return RASM_TRUE;
	}
	return RASM_FALSE;
}

RASM_BOOL RASM_MOV(RASM_MOV_PACK src,RASM_MOV_PACK dst)
{
	/*
		type:
			0:user-mem
			1:reg
			2:num
	*/
	if(src.type==0){
		if(dst.type==1){
			if(*(RASM_uWORD*)(dst.val)<=RASM_DX*2){
				if(*(RASM_uWORD*)(dst.val)%2==1)
					RASM_MEM[RASM_MEM_NP][*(RASM_uWORD*)(src.val)] = (RASM_BYTE)(RASM_REG[*(RASM_uWORD*)(dst.val)/2]>>8);
				else
					RASM_MEM[RASM_MEM_NP][*(RASM_uWORD*)(src.val)] = (RASM_BYTE)(RASM_REG[*(RASM_uWORD*)(dst.val)/2]);
			}else{
				return RASM_FALSE;
			}
		}else{
			return RASM_FALSE;
		}
	}else
	if(src.type==1){
		if(dst.type==0){
			//mem
			if(*(RASM_uWORD*)(dst.val)<=RASM_DX*2){
				if(*(RASM_uWORD*)(src.val)%2==0)
					RASM_REG[*(RASM_uWORD*)(src.val)/2] = (RASM_BYTE)(RASM_MEM[RASM_MEM_NP][*(RASM_uWORD*)(dst.val)]>>8);
				else
					RASM_REG[*(RASM_uWORD*)(src.val)/2] = (RASM_BYTE)(RASM_MEM[RASM_MEM_NP][*(RASM_uWORD*)(dst.val)]);
			}else{
				return RASM_FALSE;
			}
		}else
		if(dst.type==1){
			//reg
			if(*(RASM_uWORD*)(dst.val)>RASM_DX*2){
				RASM_REG[*(RASM_uWORD*)(src.val)-RASM_DX*2] = RASM_REG[*(RASM_uWORD*)(dst.val)-RASM_DX*2];
			}else{
				return RASM_FALSE;
			}
		}else
		if(dst.type==2){
			if(*(RASM_uWORD*)(src.val)<=RASM_DX*2){
				if(*(RASM_uWORD*)(src.val)%2==1){
					RASM_WORD tmp = *(RASM_BYTE*)(dst.val);
					tmp = tmp<<8;
					/*tmp = tmp<<8;
					tmp+=(RASM_BYTE)RASM_REG[*(RASM_uWORD*)(src.val)];
					RASM_REG[*(RASM_uWORD*)(src.val)] = tmp;*/
					RASM_WORD tmp2 = RASM_REG[*(RASM_uWORD*)(src.val)];
					tmp2 = tmp2<<8;
					tmp2 = tmp2>>8;
					RASM_REG[*(RASM_uWORD*)(src.val)/2] = tmp + tmp2;
				}else{
					RASM_WORD tmp = RASM_REG[*(RASM_uWORD*)(src.val)];
					tmp = tmp>>8;
					tmp = tmp<<8;
					tmp+= *(RASM_BYTE*)(dst.val);
					RASM_REG[*(RASM_uWORD*)(src.val)/2] = tmp;
				}
			}else{
				return RASM_FALSE;
			}
		}else
		return RASM_FALSE;
	}else	return RASM_FALSE;
	return RASM_TRUE;	//that's ok
}

RASM_BOOL RASM_MOVL(RASM_MOV_PACK src)
{
	
}

RASM_BOOL RASM_MOVC(RASM_MOV_PACK src,RASM_MOV_PACK dst)
{
	RASM_uWORD addr = *(RASM_uWORD*)src.val;
	if(addr>64*1024-1)	return RASM_FALSE;
	char c			= *(char*)dst.val;
	RASM_MEM[RASM_MEM_NP][addr] = c;
	return RASM_TRUE;
}

RASM_BOOL RASM_CALLL(void)
{
	
}

RASM_BOOL RASM_PUSH(RASM_MOV_PACK dst){
	
}

RASM_BOOL RASM_POP(RASM_MOV_PACK scr)
{
	
}

main()
{
	/*
		�һ����ýӿ�ִ������������䣺
		MOV AH 13
		MOV [0] AH
		MOV BL [0]
		��������BH����֤�ӿ��Ƿ���bug 
		��������ASCII�������������֣�RASM!!
		��Rȡ���������һ�����١���ƴ������ĸ��        
	*/
	
	RASM_MOV_PACK src,dst;
	void* v1 = malloc(2);
	void* v2 = malloc(2);
	*(RASM_uWORD*)v1
}
