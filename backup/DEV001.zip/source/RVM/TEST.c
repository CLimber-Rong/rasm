#include<stdio.h>
#include<stdlib.h>

main()
{
	unsigned int a = 0xFFFFFFFF;
	printf("%d",a);
}
