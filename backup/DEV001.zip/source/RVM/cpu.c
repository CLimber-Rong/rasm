/*
 * Write CPU here
*/

#include"mem.c"

/*Arithmetic operation section*/

/*Logical operation section*/
