#include<stdio.h>
#include<stdlib.h>

void p()
{
	printf("Hello world!\n");
	system("pause");
	return;
}
