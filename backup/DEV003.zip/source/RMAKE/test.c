#include"test.h"

int main()
{
	p();
	return 0;
}
